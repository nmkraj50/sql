use Training_13Aug19_Pune
go

--Create a Filtered Index HumanResources.Employee table present in the
--AdventureWorks database for the column EmployeeID. The index should cover all
--the queries that uses EmployeeID for its search & that select only rows with
--�Marketing Manager� for Title column.

CREATE NONCLUSTERED INDEX NCI_Department
ON HumanResources.Employee(EmployeeID)
WHERE Title= 'Marketing Manager'

--------------------------------------------------------------------------------------