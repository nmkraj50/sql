use Training_13Aug19_Pune
go

--Write a query that displays Staff Name, Salary, and Grade of all staff

select Staff_Name, Salary, 
(case
	when Salary>=50000 then 'A'
	when Salary<50000 and Salary>=25000 then 'B'
	when Salary>=10000 and Salary<25000 then 'C'
	when Salary<10000 then 'D' 
end) 
as Grade
from Staff_Master;

-----------------------------------------------------------------------------
--Generate a report which contains the following information

select a.Staff_Code,a.Staff_Name,b.Design_Name,c.Dept_Name,
d.Book_Code,d.Book_Name,d.Author, 
(5*datediff(day,Exp_Return_date,getdate())) as Fine
from Staff_Master a,Desig_Master b,Department_Master c,Book_Master d,Book_Transaction e
where a.Des_Code=b.Design_Code and a.Dept_Code=c.Dept_Code and a.Staff_Code=e.Staff_Code and d.Book_Code=e.Book_Code
and e.Actual_Return_date is null
union
select a.Staff_Code,a.Staff_Name,b.Design_Name,c.Dept_Name,
d.Book_Code,d.Book_Name,d.Author, '0' as Fine
from Staff_Master a,Desig_Master b,Department_Master c,Book_Master d,Book_Transaction e
where a.Des_Code=b.Design_Code and a.Dept_Code=c.Dept_Code and a.Staff_Code=e.Staff_Code and d.Book_Code=e.Book_Code
and e.Actual_Return_date is not null

-------------------------------------------------------------------------------------------

--List out all the staffs who are reporting to the same manager to whom staff 100060
--reports to.

select * 
from Staff_Master
where Mgr_Code = (select Mgr_Code from Staff_Master where Staff_Code=100060);

-----------------------------------------------------------------------------------------

--List out all the students along with the department who reads the same books which
--the professors read

select a.Stud_Code,a.Stud_Name,a.Dept_Code,a.Stud_Dob,a.Address,b.Dept_Name
from Student_Master a,Department_Master b
where a.Dept_Code = b.Dept_Code 
and a.Stud_Code in (select c.Stud_Code
					from Student_Master c,Book_Transaction d
					where c.Stud_Code = d.Stud_Code 
					and d.Book_Code in (select f.Book_Code
					                    from Staff_Master e, Book_Transaction f,Desig_Master g
					                     where e.Staff_Code=f.Staff_code and e.Des_Code=g.Design_Code 
					                     and g.Design_Name='Professor')
					)


-----------------------------------------------------------------------------------------------------------

--List out all the authors who have written books on same category as written by
--Author David Gladstone.

select distinct Author 
from Book_Master
where Book_Category = (select Book_Category from Book_master where Author='David Gladstone')

------------------------------------------------------------------------------------------------------

--Display the Student report Card for this year. The report Card should contain the
--following information.

select a.Stud_Code as 'Student Code',a.Stud_name as'Student Name', Dept_name as 'Department Name',
(IsNull(Subject1,0)+IsNull(Subject2,0)+IsNull(Subject3,0)) as 'Total Marks',
(case
		when (IsNull(Subject1,0)+IsNull(Subject2,0)+IsNull(Subject3,0))/3 >80 then 'E'
		when (IsNull(Subject1,0)+IsNull(Subject2,0)+IsNull(Subject3,0))/3 <=80 and (IsNull(Subject1,0)+IsNull(Subject2,0)+IsNull(Subject3,0))/3 >70 then 'A'
		when (IsNull(Subject1,0)+IsNull(Subject2,0)+IsNull(Subject3,0))/3 <=70 and (IsNull(Subject1,0)+IsNull(Subject2,0)+IsNull(Subject3,0))/3 >60 then 'B'
		when ((IsNull(Subject1,0)+IsNull(Subject2,0)+IsNull(Subject3,0))/3 <=60) or (Subject1 is null or Subject2 is null or Subject3 is null) then 'F'
end) as 'Grade'
from Student_Master a,Department_Master b,Student_Marks c
where a.Stud_Code = c.Stud_Code and a.Dept_Code =b.Dept_Code

---------------------------------------------------------------------------------------------