use Training_13Aug19_Pune
go

--create schema [University_46003367]
--go

--List out Student_Code, Student_Name and Department_Code of every Student

select Stud_Code,Stud_Name,Dept_Code
from Student_Master;

--------------------------------------------------------------------------------------------------------------------------------------
--Do the same for all the staff�s

select Staff_Code,Staff_Name,Dept_Code
from Staff_Master;

---------------------------------------------------------------------------------------------------------------------------------------
--Retrieve the details (Name, Salary and dept code) of the employees who are working
--in department 20, 30 and 40.

select Staff_Name as Name, Salary, Dept_code as 'Dept Code'
from Staff_Master 
where Dept_code in (20,30,40);

---------------------------------------------------------------------------------------------------------------------------------------

--Display Student_Code, Subjects and Total_Marks for every student. Total_Marks will
--calculate as Subject1 + Subject2 + Subject3 from Student_Marks. The records
--should be displayed in the descending order of Total Score

select Stud_Code,Subject1,Subject2,Subject3,(IsNULL(Subject1,0)+IsNULL(Subject2,0)+IsNULL(Subject3,0)) as Total_Marks
from Student_Marks
order by Total_Marks;

---------------------------------------------------------------------------------------------------------------------------------------

--List out all the books which starts with �An�, along with price

select Book_Name------Price not available in table 
from Book_Master
where Book_Name like 'In%';

---------------------------------------------------------------------------------------------------------------------------------------

--List out all the department codes in which students have joined this year

select dept_code 
from Student_Master a inner join Student_Marks b
on a.Stud_Code = b.Stud_Code
where Stud_Year = 2007;   --YEAR DATA/JOINING DATE NOT SUPPLIED 

---------------------------------------------------------------------------------------------------------------------------------------

--Display name and date of birth of students where date of birth must be displayed in
--the format similar to �January, 12 1981� for those who were born on Saturday or
--Sunday.

select Stud_Name, convert(varchar,Stud_Dob,107) as 'Date of Birth'
from Student_Master
where datepart(dw,Stud_Dob) in (7,1);

select Stud_Name, convert(varchar,Stud_Dob,107) as 'Date of Birth'
from Student_Master
where datename(dw,Stud_Dob) in ('Saturday','Sunday');

---------------------------------------------------------------------------------------------------------------------------------------

--List out a report like this
--StaffCode StaffName Dept Code Date of Joining No of years in the Company

select Staff_Code as StaffCode, Staff_Name as StaffName, Dept_Code as 'Dept Code',
HireDate as 'Date of Joining', datediff(year,HireDate,getdate()) as 'No of years in the Company'
from Staff_Master;

---------------------------------------------------------------------------------------------------------------------------------------

--List out all staffs who have joined before Jan 2000

select * from Staff_Master
where HireDate > datefromparts(2000,1,1);-------NO STAFF JOINED BEFORE 1/1/2000

---------------------------------------------------------------------------------------------------------------------------------------

--Write a query which will display Student_Name, Departmnet_Code and DOB of all
--students who born between January 1, 1981 and March 31, 1983.

select Stud_Name,Dept_Code,Stud_Dob
from Student_Master
where Stud_Dob between datefromparts(1981,1,1) and datefromparts(1983,3,31);

---------------------------------------------------------------------------------------------------------------------------------------

--List out all student codes who did not appear in the exam subject2

select Stud_Code 
from Student_Marks
where Subject2 is null;

---------------------------------------------------------------------------------------------------------------------------------------


 