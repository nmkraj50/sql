
USE Training_13Aug19_Pune
Go

-------------------------CASE STUDY 1------------------------------

CREATE TABLE Products_46003367
(
ProductID INT PRIMARY KEY,
ProductName VARCHAR(100),
Rate MONEY
)

---------------------------------------------------------------------------------------------------------------------------------------
--Insert records into target table

INSERT INTO Products_46003367
VALUES
(1,'Tea', 10.00),
(2, 'Coffee', 20.00),
(3, 'Muffin', 30.00),
(4, 'Biscuit', 40.00)

CREATE TABLE UpdatedProducts_46003367
(
ProductID INT PRIMARY KEY,
ProductName VARCHAR(100),
Rate MONEY
)

---------------------------------------------------------------------------------------------------------------------------------------

--Insert records into source table
INSERT INTO UpdatedProducts_46003367
VALUES
(1, 'Tea', 10.00),
(2, 'Coffee', 25.00),
(3, 'Muffin', 35.00),
(5, 'Pizza', 60.00)

MERGE Products_46003367 AS TARGET
USING UpdatedProducts_46003367 AS SOURCE
ON (TARGET.ProductID = SOURCE.ProductID)
WHEN MATCHED AND TARGET.ProductName <> SOURCE.ProductName
OR TARGET.Rate <> SOURCE.Rate THEN
UPDATE SET TARGET.ProductName = SOURCE.ProductName,
TARGET.Rate = SOURCE.Rate
WHEN NOT MATCHED BY TARGET THEN
INSERT (ProductID, ProductName, Rate)
VALUES (SOURCE.ProductID, SOURCE.ProductName, SOURCE.Rate)
WHEN NOT MATCHED BY SOURCE THEN
DELETE
OUTPUT $action,
DELETED.ProductID AS TargetProductID,
DELETED.ProductName AS TargetProductName,
DELETED.Rate AS TargetRate,
INSERTED.ProductID AS SourceProductID,
INSERTED.ProductName AS SourceProductName,
INSERTED.Rate AS SourceRate;
SELECT @@ROWCOUNT;
GO

---------------------------------------------------------------------------------------------------------------------------------------

-------------------------CASE STUDY 2------------------------------

----Target Table
--CREATE TABLE EmployeeTarget
--(
--EmpID INT NOT NULL,
--Designation VARCHAR (25) NOT NULL,
--Phone VARCHAR (20) NOT NULL,
--Address VARCHAR (50) NOT NULL,
--CONSTRAINT PK_EmployeeTG
--PRIMARY KEY (EmpID)
--)

----Source Table
--CREATE TABLE EmployeeSource
--(
--EmpID INT NOT NULL,
--Designation VARCHAR (25) NOT NULL,
--Phone VARCHAR (20) NOT NULL,
--Address VARCHAR (50) NOT NULL,
--CONSTRAINT PK_EmployeeSC
--PRIMARY KEY (EmpID)
--)

--Employee Table

CREATE TABLE Employee_46003367
(
Employee_Number INT NOT NULL PRIMARY
KEY,
Employee_Name VARCHAR(30) NULL,
Salary FLOAT NULL,
Department_Number INT NULL,
Region VARCHAR(30) NULL
)

INSERT INTO Employee_46003367
VALUES
(101, 'ARITRA', 20000.00,1234,'PUNE'),
(102, 'ABHIJEET', 30000.00,1235,'MUMBAI'),
(103, 'SOUMYADIP', 40000.00,1234,'THANE'),
(104, 'PRINCE', 50000.00,1236,'NASIK'),
(105, 'ANURAG', 30000.00,1236,'NAGPUR')

SELECT Region, Department_Number, AVG (Salary)
Average_Salary
FROM Employee_46003367
GROUP BY GROUPING SETS
( (Region, Department_Number),
(Region),
(Department_Number)
)

---------------------------------------------------------------------------------------------------------------------------------------

SELECT Region, Department_Number, AVG(Salary) Average_Salary
FROM Employee_46003367
GROUP BY (Region), (Department_Number)
UNION
SELECT Region, Department_Number, AVG(Salary) Average_Salary ---ERROR AS REGION IS NOT PRESENT IN GROUP BY OR AGGREGATE FUNCTION
FROM Employee_46003367
GROUP BY (Region)
UNION
SELECT Region, Department_Number, AVG (Salary) Average_Salary ---ERROR AS DEPAERTMENT_NUMBER IS NOT PRESENT IN GROUP BY OR AGGREGATE FUNCTION
FROM Employee_46003367
GROUP BY (Department_Number)

---------------------------------------------------------------------------------------------------------------------------------------